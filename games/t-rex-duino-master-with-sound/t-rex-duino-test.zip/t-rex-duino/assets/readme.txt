***
Files in this folder are auto generated. Do not edit them.
See `gen_assets.bat` and `img-conv.py` for more info.
***
